/**
 * SAFRAAQUI - Sistema de Autenticação e Gestão de Usuários
 * Módulo de Autenticação v1.0
 */

// =====================================================
// DADOS MOCKADOS DE USUÁRIOS
// =====================================================
const MOCK_USERS = {
    produtores: [
        {
            id: 'prod-001',
            name: 'Carlos Silva Mendes',
            email: 'carlos@fazendaouro.com.br',
            phone: '(65) 99876-5432',
            role: 'produtor',
            farm: 'Fazenda Ouro Verde',
            location: 'Lucas do Rio Verde - MT',
            createdAt: '2024-01-15'
        },
        {
            id: 'prod-002',
            name: 'Marcos Antônio Souza',
            email: 'marcos@saolucas.com.br',
            phone: '(66) 98765-1234',
            role: 'produtor',
            farm: 'Fazenda São Lucas',
            location: 'Sorriso - MT',
            createdAt: '2024-02-20'
        }
    ],
    prestadores: [
        {
            id: 'pres-001',
            name: 'Roberto Carlos Pereira',
            email: 'contato@agroservicosmt.com.br',
            phone: '(65) 98765-4321',
            role: 'prestador',
            company: 'Agro Serviços Mato Grosso',
            location: 'Cuiabá - MT',
            specialties: ['colheita', 'pulverizacao'],
            rating: 4.8,
            totalEvaluations: 45,
            createdAt: '2023-11-10'
        },
        {
            id: 'pres-002',
            name: 'José da Silva Equips',
            email: 'jose@maquinasequipamentos.com.br',
            phone: '(65) 91234-5678',
            role: 'prestador',
            company: 'Máquinas e Equipamentos',
            location: 'Rondonópolis - MT',
            specialties: ['colheita', 'plantio', 'transporte'],
            rating: 4.6,
            totalEvaluations: 32,
            createdAt: '2023-12-05'
        },
        {
            id: 'pres-003',
            name: 'Pedro Nogueira',
            email: 'pedro@droneagro.com.br',
            phone: '(11) 99876-5432',
            role: 'prestador',
            company: 'Drone Agro Tecnologia',
            location: 'Goiânia - GO',
            specialties: ['pulverizacao'],
            rating: 4.9,
            totalEvaluations: 28,
            createdAt: '2024-01-08'
        }
    ]
};

// =====================================================
// DADOS MOCKADOS DE SOLICITAÇÕES
// =====================================================
let MOCK_REQUESTS = [
    {
        id: 'req-001',
        producerId: 'prod-001',
        producerName: 'Carlos Silva Mendes',
        farm: 'Fazenda Ouro Verde',
        type: 'colheita',
        typeLabel: 'Colheita de Soja',
        culture: 'soja',
        cultureLabel: 'Soja',
        area: 500,
        location: 'Lucas do Rio Verde - MT',
        coordinates: [-55.9832, -12.9914],
        date: '2024-01-25',
        status: 'pending',
        description: 'Área de soja madura, acesso por estrada asfaltada. Necessário colheitadeira com plataforma de 30 pés.',
        createdAt: '2024-01-20T10:00:00'
    },
    {
        id: 'req-002',
        producerId: 'prod-002',
        producerName: 'Marcos Antônio Souza',
        farm: 'Fazenda São Lucas',
        type: 'pulverizacao',
        typeLabel: 'Pulverização',
        culture: 'milho',
        cultureLabel: 'Milho',
        area: 350,
        location: 'Sorriso - MT',
        coordinates: [-55.7000, -12.5500],
        date: '2024-01-26',
        status: 'pending',
        description: 'Pulverização de defensivos agrícolas. Terreno plano, sem restrições.',
        createdAt: '2024-01-21T14:30:00'
    },
    {
        id: 'req-003',
        producerId: 'prod-001',
        producerName: 'Carlos Silva Mendes',
        farm: 'Fazenda Ouro Verde',
        type: 'transporte',
        typeLabel: 'Transporte',
        culture: 'soja',
        cultureLabel: 'Soja (Grão)',
        area: 200,
        location: 'Lucas do Rio Verde - MT',
        coordinates: [-55.9832, -12.9914],
        date: '2024-01-27',
        status: 'pending',
        description: 'Transporte de soja colhida até armazém. Carga de aproximadamente 6000 sacas.',
        createdAt: '2024-01-22T09:15:00'
    },
    {
        id: 'req-004',
        producerId: 'prod-002',
        producerName: 'Marcos Antônio Souza',
        farm: 'Fazenda São Lucas',
        type: 'colheita',
        typeLabel: 'Colheita de Milho',
        culture: 'milho',
        cultureLabel: 'Milho',
        area: 420,
        location: 'Sorriso - MT',
        coordinates: [-55.7000, -12.5500],
        date: '2024-01-28',
        status: 'accepted',
        acceptedBy: 'pres-001',
        acceptedByName: 'Agro Serviços Mato Grosso',
        description: 'Colheita de milho segunda safra. Expectativa de produtividade alta.',
        createdAt: '2024-01-22T16:00:00'
    }
];

// =====================================================
// DADOS MOCKADOS DE PRESTADORES (PARA MAPA DO PRODUTOR)
// =====================================================
let MOCK_PROVIDERS = [
    {
        id: 'pres-001',
        name: 'Agro Serviços Mato Grosso',
        location: 'Cuiabá - MT',
        coordinates: [-56.0963, -15.5961],
        specialties: ['colheita', 'pulverizacao'],
        rating: 4.8,
        available: true
    },
    {
        id: 'pres-002',
        name: 'Máquinas e Equipamentos',
        location: 'Rondonópolis - MT',
        coordinates: [-54.6200, -16.4700],
        specialties: ['colheita', 'plantio', 'transporte'],
        rating: 4.6,
        available: true
    },
    {
        id: 'pres-003',
        name: 'Drone Agro Tecnologia',
        location: 'Goiânia - GO',
        coordinates: [-49.2642, -16.6864],
        specialties: ['pulverizacao'],
        rating: 4.9,
        available: false
    },
    {
        id: 'pres-004',
        name: 'Terra Máquinas',
        location: 'Sinop - MT',
        coordinates: [-55.5000, -11.8500],
        specialties: ['colheita', 'transporte'],
        rating: 4.5,
        available: true
    }
];

// =====================================================
// DADOS MOCKADOS DE OPORTUNIDADES (PARA MAPA DO PRESTADOR)
// =====================================================
let MOCK_OPPORTUNITIES = [
    {
        id: 'opp-001',
        type: 'colheita',
        typeLabel: 'Colheita de Soja',
        culture: 'soja',
        cultureLabel: 'Soja',
        area: 500,
        location: 'Lucas do Rio Verde - MT',
        coordinates: [-55.9832, -12.9914],
        distance: 45,
        producer: 'Fazenda Ouro Verde',
        description: 'Área de soja madura, acesso por estrada asfaltada.',
        estimatedValue: 25000,
        urgency: 'high'
    },
    {
        id: 'opp-002',
        type: 'pulverizacao',
        typeLabel: 'Pulverização',
        culture: 'milho',
        cultureLabel: 'Milho',
        area: 350,
        location: 'Sorriso - MT',
        coordinates: [-55.7000, -12.5500],
        distance: 32,
        producer: 'Fazenda São Lucas',
        description: 'Pulverização de defensivos agrícolas. Terreno plano.',
        estimatedValue: 10500,
        urgency: 'medium'
    },
    {
        id: 'opp-003',
        type: 'transporte',
        typeLabel: 'Transporte',
        culture: 'soja',
        cultureLabel: 'Soja (Grão)',
        area: 200,
        location: 'Lucas do Rio Verde - MT',
        coordinates: [-55.9832, -12.9914],
        distance: 45,
        producer: 'Fazenda Ouro Verde',
        description: 'Transporte de soja colhida até armazém.',
        estimatedValue: 8000,
        urgency: 'low'
    },
    {
        id: 'opp-004',
        type: 'colheita',
        typeLabel: 'Colheita de Milho',
        culture: 'milho',
        cultureLabel: 'Milho',
        area: 280,
        location: 'Nova Mutum - MT',
        coordinates: [-56.0800, -13.8400],
        distance: 68,
        producer: 'Fazenda Vale do Juruena',
        description: 'Colheita de milho segunda safra. Área com boa produtividade.',
        estimatedValue: 14000,
        urgency: 'medium'
    },
    {
        id: 'opp-005',
        type: 'pulverizacao',
        typeLabel: 'Pulverização',
        culture: 'algodao',
        cultureLabel: 'Algodão',
        area: 180,
        location: 'Campo Verde - MT',
        coordinates: [-55.1700, -15.0400],
        distance: 85,
        producer: 'Fazenda Cerrado',
        description: 'Pulverização de defensivos em cultura de algodão.',
        estimatedValue: 9000,
        urgency: 'high'
    }
];

// =====================================================
// FUNÇÕES DE AUTENTICAÇÃO
// =====================================================

/**
 * Inicializa o sistema de autenticação
 */
function initAuth() {
    checkAuth();
    setupFormListeners();
}

/**
 * Verifica se usuário está autenticado
 */
function checkAuth() {
    const user = getCurrentUser();
    if (user) {
        updateUserInterface(user);
    }
}

/**
 * Atualiza a interface com dados do usuário
 */
function updateUserInterface(user) {
    // Atualiza nome do usuário na sidebar
    const userNameElements = document.querySelectorAll('#userName');
    userNameElements.forEach(el => {
        el.textContent = user.name || user.company;
    });

    // Atualiza avatar do usuário
    const userAvatars = document.querySelectorAll('.user-avatar');
    userAvatars.forEach(el => {
        const initial = (user.name || user.company).charAt(0).toUpperCase();
        el.innerHTML = `<i class="fas fa-user"></i>`;
    });
}

/**
 * Obtém o usuário atual logado
 */
function getCurrentUser() {
    const userData = localStorage.getItem('safraaqui_user');
    if (userData) {
        return JSON.parse(userData);
    }
    return null;
}

/**
 * Obtém o tipo de usuário atual
 */
function getCurrentUserType() {
    const user = getCurrentUser();
    return user ? user.role : null;
}

/**
 * Configura listeners dos formulários
 */
function setupFormListeners() {
    // Formulário de login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Formulário de registro
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }

    // Formulário de perfil
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', handleProfileUpdate);
    }

    const providerProfileForm = document.getElementById('providerProfileForm');
    if (providerProfileForm) {
        providerProfileForm.addEventListener('submit', handleProfileUpdate);
    }
}

/**
 * Manipula o login do usuário
 */
function handleLogin(event) {
    event.preventDefault();

    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const userType = localStorage.getItem('safraaqui_selected_role') || 'produtor';

    // Simula validação de login
    if (email && password) {
        // Busca usuário mockado
        const userList = userType === 'produtor' ? MOCK_USERS.produtores : MOCK_USERS.prestadores;
        const user = userList[0]; // Usa o primeiro usuário mockado como demo

        if (user) {
            // Armazena dados do usuário
            localStorage.setItem('safraaqui_user', JSON.stringify(user));
            localStorage.setItem('safraaqui_token', 'mock_token_' + Date.now());

            // Fecha modal e redireciona
            closeModal('loginModal');
            showNotification('Login realizado com sucesso!', 'success');

            // Redireciona para dashboard apropriado
            setTimeout(() => {
                if (user.role === 'produtor') {
                    window.location.href = 'dashboard-produtor.html';
                } else {
                    window.location.href = 'dashboard-prestador.html';
                }
            }, 500);
        }
    }
}

/**
 * Manipula o registro de novo usuário
 */
function handleRegister(event) {
    event.preventDefault();

    const userType = localStorage.getItem('safraaqui_selected_role') || 'produtor';
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const phone = document.getElementById('registerPhone').value;

    // Cria objeto de usuário
    const newUser = {
        id: userType === 'produtor' ? 'prod-' + Date.now() : 'pres-' + Date.now(),
        name: name,
        email: email,
        phone: phone,
        role: userType,
        createdAt: new Date().toISOString().split('T')[0]
    };

    if (userType === 'produtor') {
        newUser.farm = 'Nova Fazenda';
        newUser.location = 'A definir';
    } else {
        newUser.company = name;
        newUser.location = 'A definir';
        newUser.specialties = [];
        newUser.rating = 0;
        newUser.totalEvaluations = 0;
    }

    // Armazena dados do usuário
    localStorage.setItem('safraaqui_user', JSON.stringify(newUser));
    localStorage.setItem('safraaqui_token', 'mock_token_' + Date.now());

    // Fecha modal e notifica
    closeModal('registerModal');
    showNotification('Cadastro realizado com sucesso!', 'success');

    // Redireciona para dashboard apropriado
    setTimeout(() => {
        if (newUser.role === 'produtor') {
            window.location.href = 'dashboard-produtor.html';
        } else {
            window.location.href = 'dashboard-prestador.html';
        }
    }, 500);
}

/**
 * Manipula atualização de perfil
 */
function handleProfileUpdate(event) {
    event.preventDefault();
    showNotification('Perfil atualizado com sucesso!', 'success');
}

/**
 * Faz logout do usuário
 */
function handleLogout() {
    localStorage.removeItem('safraaqui_user');
    localStorage.removeItem('safraaqui_token');
    localStorage.removeItem('safraaqui_selected_role');
    showNotification('Logout realizado com sucesso!', 'success');
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 500);
}

/**
 * Seleciona o tipo de usuário para cadastro/login
 */
function selectRole(role) {
    localStorage.setItem('safraaqui_selected_role', role);
    openModal('loginModal');
}

/**
 * Seleciona papel durante registro
 */
function selectRegisterRole(role) {
    localStorage.setItem('safraaqui_selected_role', role);

    // Atualiza visual dos botões
    const roleBtns = document.querySelectorAll('.role-btn');
    roleBtns.forEach(btn => {
        if (btn.dataset.role === role) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

/**
 * Verifica se usuário pode acessar a página
 */
function requireAuth(allowedRoles = []) {
    const user = getCurrentUser();
    const currentPage = window.location.pathname;

    if (!user) {
        // Não está logado, redireciona para home
        window.location.href = 'index.html';
        return false;
    }

    // Verifica se a página é apropriada para o tipo de usuário
    if (currentPage.includes('dashboard-produtor') && user.role !== 'produtor') {
        window.location.href = 'dashboard-prestador.html';
        return false;
    }

    if (currentPage.includes('dashboard-prestador') && user.role !== 'prestador') {
        window.location.href = 'dashboard-produtor.html';
        return false;
    }

    return true;
}

/**
 * Verifica se usuário é produtor
 */
function isProducer() {
    return getCurrentUserType() === 'produtor';
}

/**
 * Verifica se usuário é prestador
 */
function isProvider() {
    return getCurrentUserType() === 'prestador';
}

// =====================================================
// FUNÇÕES DE DADOS MOCKADOS
// =====================================================

/**
 * Obtém solicitações de serviço
 */
function getRequests() {
    const user = getCurrentUser();
    if (!user) return [];

    if (user.role === 'produtor') {
        return MOCK_REQUESTS.filter(req => req.producerId === user.id || req.producerId === 'prod-001');
    } else {
        return MOCK_REQUESTS.filter(req => req.status === 'pending' || req.acceptedBy === user.id);
    }
}

/**
 * Adiciona nova solicitação
 */
function addRequest(requestData) {
    const user = getCurrentUser();
    if (!user) return null;

    const newRequest = {
        id: 'req-' + Date.now(),
        producerId: user.id,
        producerName: user.name || user.farm,
        farm: user.farm || user.name,
        type: requestData.type,
        typeLabel: getTypeLabel(requestData.type),
        culture: requestData.culture,
        cultureLabel: getCultureLabel(requestData.culture),
        area: parseFloat(requestData.area),
        location: requestData.location,
        coordinates: requestData.coordinates || [-55.9832, -12.9914],
        date: requestData.date,
        status: 'pending',
        description: requestData.description || '',
        createdAt: new Date().toISOString()
    };

    MOCK_REQUESTS.unshift(newRequest);

    // Adiciona ao mapa do prestador como nova oportunidade
    const opportunity = {
        id: 'opp-' + Date.now(),
        type: newRequest.type,
        typeLabel: newRequest.typeLabel,
        culture: newRequest.culture,
        cultureLabel: newRequest.cultureLabel,
        area: newRequest.area,
        location: newRequest.location,
        coordinates: newRequest.coordinates,
        distance: calculateDistance(newRequest.coordinates),
        producer: newRequest.farm,
        description: newRequest.description,
        estimatedValue: estimateServiceValue(newRequest.type, newRequest.area),
        urgency: 'medium'
    };

    MOCK_OPPORTUNITIES.unshift(opportunity);

    return newRequest;
}

/**
 * Atualiza status de solicitação
 */
function updateRequestStatus(requestId, status, providerId = null, providerName = null) {
    const request = MOCK_REQUESTS.find(req => req.id === requestId);
    if (request) {
        request.status = status;
        if (status === 'accepted') {
            request.acceptedBy = providerId;
            request.acceptedByName = providerName;
        }
    }
}

/**
 * Obtém prestadores disponíveis
 */
function getProviders() {
    return MOCK_PROVIDERS.filter(p => p.available);
}

/**
 * Obtém prestador por ID
 */
function getProviderById(providerId) {
    return MOCK_PROVIDERS.find(p => p.id === providerId);
}

/**
 * Obtém oportunidades para prestador
 */
function getOpportunities() {
    return MOCK_OPPORTUNITIES;
}

/**
 * Obtém oportunidade por ID
 */
function getOpportunityById(opportunityId) {
    return MOCK_OPPORTUNITIES.find(op => op.id === opportunityId);
}

/**
 * Calcula distância aproximada entre coordenadas
 */
function calculateDistance(coordinates) {
    // Centro de referência: Lucas do Rio Verde (-55.9832, -12.9914)
    const refCoords = [-55.9832, -12.9914];
    const distance = Math.sqrt(
        Math.pow(coordinates[0] - refCoords[0], 2) +
        Math.pow(coordinates[1] - refCoords[1], 2)
    );
    return Math.round(distance * 100); // Aproximação
}

/**
 * Estima valor do serviço baseado no tipo e área
 */
function estimateServiceValue(type, area) {
    const rates = {
        'colheita': 50,      // R$ por hectare
        'plantio': 40,       // R$ por hectare
        'pulverizacao': 30,  // R$ por hectare
        'transporte': 40     // R$ por hectare
    };

    const rate = rates[type] || 40;
    return Math.round(area * rate);
}

/**
 * Obtém label do tipo de serviço
 */
function getTypeLabel(type) {
    const labels = {
        'colheita': 'Colheita',
        'plantio': 'Plantio',
        'pulverizacao': 'Pulverização',
        'transporte': 'Transporte'
    };
    return labels[type] || type;
}

/**
 * Obtém label da cultura
 */
function getCultureLabel(culture) {
    const labels = {
        'soja': 'Soja',
        'milho': 'Milho',
        'algodao': 'Algodão',
        'cafe': 'Café',
        'cana': 'Cana-de-açúcar'
    };
    return labels[culture] || culture;
}

// =====================================================
// INICIALIZAÇÃO
// =====================================================

// Inicializa quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    initAuth();
});
