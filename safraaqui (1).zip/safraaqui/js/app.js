/**
 * SAFRAAQUI - Aplicação Principal
 * Lógica de Interface e Funcionalidades v1.0
 */

// =====================================================
// INICIALIZAÇÃO DA APLICAÇÃO
// =====================================================

/**
 * Inicializa todos os componentes da aplicação
 */
function initApp() {
    checkAuthAndSetup();
    setupNavigation();
    setupModals();
    setupFilters();
    populateMockData();
    setupMapClick();
    setupFormHandlers();
    setupEventListeners();
}

/**
 * Verifica autenticação e configura dashboard
 */
function checkAuthAndSetup() {
    const user = getCurrentUser();
    
    if (user) {
        updateUserInterface(user);
        
        // Configura dashboard específico
        if (window.location.pathname.includes('dashboard-produtor')) {
            requireAuth(['produtor']);
            initProducerDashboard();
        } else if (window.location.pathname.includes('dashboard-prestador')) {
            requireAuth(['prestador']);
            initProviderDashboard();
        }
    }
}

/**
 * Configura navegação do dashboard
 */
function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item[data-section]');
    
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Remove classe active de todos os nav items
            navItems.forEach(nav => nav.classList.remove('active'));
            
            // Adiciona classe active ao item clicado
            item.classList.add('active');
            
            // Mostra seção correspondente
            const sectionName = item.dataset.section;
            showSection(sectionName);
            
            // Atualiza título da página
            updatePageTitle(sectionName);
        });
    });
}

/**
 * Exibe seção específica do dashboard
 */
function showSection(sectionName) {
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.classList.remove('active');
    });
    
    const targetSection = document.getElementById(`${sectionName}-section`);
    if (targetSection) {
        targetSection.classList.add('active');
    }
}

/**
 * Atualiza título da página baseado na seção
 */
function updatePageTitle(sectionName) {
    const titles = {
        'dashboard': 'Dashboard',
        'solicitacoes': 'Minhas Solicitações',
        'prestadores': 'Prestadores Disponíveis',
        'pagamentos': 'Pagamentos',
        'perfil': 'Meu Perfil',
        'oportunidades': 'Buscar Oportunidades',
        'servicos': 'Meus Serviços',
        'rotas': 'Minhas Rotas',
        'financas': 'Financeiro',
        'equipamentos': 'Equipamentos'
    };
    
    const titleEl = document.getElementById('pageTitle');
    if (titleEl) {
        titleEl.textContent = titles[sectionName] || 'Dashboard';
    }
}

// =====================================================
// CONFIGURAÇÃO DE MODAIS
// =====================================================

/**
 * Configura listeners de modais
 */
function setupModals() {
    // Configura botões de abrir modal
    document.querySelectorAll('[onclick^="openModal"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const modalId = btn.getAttribute('onclick').match(/'([^']+)'/)[1];
            openModal(modalId);
        });
    });

    // Configura botões de fechar modal
    document.querySelectorAll('.modal-close, .modal-overlay').forEach(el => {
        el.addEventListener('click', () => {
            const modal = el.closest('.modal');
            if (modal) {
                closeModal(modal.id);
            }
        });
    });

    // Fecha modal com ESC
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const activeModal = document.querySelector('.modal.active');
            if (activeModal) {
                closeModal(activeModal.id);
            }
        }
    });
}

/**
 * Abre modal específico
 */
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Inicializa mapa se modal contiver mapa
        if (modal.querySelector('.map-container') && !map) {
            setTimeout(() => {
                initMap();
            }, 200);
        }
    }
}

/**
 * Fecha modal específico
 */
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

/**
 * Alterna entre modais
 */
function switchModal(fromModalId, toModalId) {
    closeModal(fromModalId);
    setTimeout(() => {
        openModal(toModalId);
    }, 200);
}

// =====================================================
// MENU MOBILE
// =====================================================

/**
 * Alterna menu mobile
 */
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    if (mobileMenu) {
        mobileMenu.classList.toggle('active');
    }
}

/**
 * Alterna sidebar do dashboard
 */
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.classList.toggle('active');
    }
}

// =====================================================
// FILTROS
// =====================================================

/**
 * Configura filtros do dashboard
 */
function setupFilters() {
    // Filtros de chips no mapa do prestador
    const filterChips = document.querySelectorAll('.filter-chip');
    filterChips.forEach(chip => {
        chip.addEventListener('click', () => {
            // Remove active de todos
            filterChips.forEach(c => c.classList.remove('active'));
            // Adiciona ao clicado
            chip.classList.add('active');
            
            // Filtra marcadores
            const filter = chip.dataset.filter;
            filterMarkersByType(filter);
            
            // Atualiza lista de oportunidades
            filterOpportunitiesList(filter);
        });
    });

    // Status tabs
    const statusTabs = document.querySelectorAll('.status-tab');
    statusTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            statusTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            const status = tab.dataset.status;
            filterServicesTable(status);
        });
    });
}

/**
 * Filtra lista de oportunidades baseado no tipo
 */
function filterOpportunitiesList(type) {
    const opportunities = getOpportunities();
    const filtered = type === 'all' ? opportunities : opportunities.filter(op => op.type === type);
    renderOpportunities(filtered);
}

/**
 * Filtra tabela de serviços
 */
function filterServicesTable(status) {
    const tableBody = document.getElementById('servicesTable');
    if (!tableBody) return;

    const allServices = getMockServices();
    const filtered = status === 'ativos' 
        ? allServices.filter(s => s.status === 'active' || s.status === 'in_progress')
        : allServices.filter(s => s.status === status);
    
    renderServicesTable(filtered);
}

// =====================================================
// POPULAÇÃO DE DADOS MOCKADOS
// =====================================================

/**
 * Popula dados mockados na interface
 */
function populateMockData() {
    if (window.location.pathname.includes('dashboard-produtor')) {
        populateProducerData();
    } else if (window.location.pathname.includes('dashboard-prestador')) {
        populateProviderData();
    }
}

/**
 * Popula dados do dashboard do produtor
 */
function populateProducerData() {
    // Popula atividades recentes
    renderRecentActivity();
    
    // Popula solicitações
    renderRequests();
    
    // Popula prestadores
    renderProviders();
    
    // Popula pagamentos
    renderPaymentsTable();
}

/**
 * Popula dados do dashboard do prestador
 */
function populateProviderData() {
    // Popula jobs recentes
    renderRecentJobs();
    
    // Popula oportunidades
    renderOpportunities(getOpportunities());
    
    // Popula tabela de serviços
    renderServicesTable(getMockServices());
    
    // Popula rotas
    renderRoutes();
    
    // Popula pagamentos
    renderProviderPayments();
    
    // Popula equipamentos
    renderEquipment();
}

/**
 * Renderiza atividades recentes
 */
function renderRecentActivity() {
    const container = document.getElementById('recentActivity');
    if (!container) return;

    const activities = [
        { icon: 'success', title: 'Serviço concluído', subtitle: 'Colheita de Soja - 500ha', time: 'Há 2 horas' },
        { icon: 'warning', title: 'Novo orçamento recebido', subtitle: 'Pulverização - R$ 10.500', time: 'Há 5 horas' },
        { icon: 'info', title: 'Prestador disponível', subtitle: 'Agro Serviços MT agora atende sua região', time: 'Há 1 dia' },
        { icon: 'success', title: 'Pagamento liberado', subtitle: 'R$ 25.000 depositado', time: 'Há 2 dias' }
    ];

    container.innerHTML = activities.map(act => `
        <div class="activity-item">
            <div class="activity-icon ${act.icon}">
                <i class="fas fa-${getActivityIcon(act.icon)}"></i>
            </div>
            <div class="activity-content">
                <p>${act.title}</p>
                <span>${act.subtitle} • ${act.time}</span>
            </div>
        </div>
    `).join('');
}

/**
 * Retorna ícone baseado no tipo de atividade
 */
function getActivityIcon(type) {
    const icons = {
        'success': 'check-circle',
        'warning': 'exclamation-circle',
        'info': 'info-circle'
    };
    return icons[type] || 'circle';
}

/**
 * Renderiza lista de solicitações
 */
function renderRequests() {
    const container = document.getElementById('requestsList');
    if (!container) return;

    const requests = getRequests();

    if (requests.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-clipboard-list"></i>
                <h3>Nenhuma solicitação ainda</h3>
                <p>Clique em "Nova Solicitação" para começar</p>
            </div>
        `;
        return;
    }

    container.innerHTML = requests.map(req => `
        <div class="request-card" onclick="showServiceDetail('${req.id}')">
            <div class="request-icon">
                <i class="fas ${getTypeIcon(req.type)}"></i>
            </div>
            <div class="request-details">
                <h4>${req.typeLabel}</h4>
                <p>${req.farm} - ${req.location}</p>
            </div>
            <span class="request-status ${req.status}">${getStatusLabel(req.status)}</span>
        </div>
    `).join('');
}

/**
 * Renderiza lista de prestadores
 */
function renderProviders() {
    const container = document.getElementById('providersGrid');
    if (!container) return;

    const providers = getProviders();

    container.innerHTML = providers.map(provider => `
        <div class="provider-card" onclick="showProviderDetail('${provider.id}')">
            <div class="provider-avatar">
                <i class="fas fa-tractor"></i>
            </div>
            <div class="provider-info">
                <h4>${provider.name}</h4>
                <p>${provider.location}</p>
                <div class="provider-rating">
                    <i class="fas fa-star"></i>
                    <span>${provider.rating}</span>
                    <span style="color: var(--gray-500); margin-left: 4px;">(${provider.specialties.map(s => getTypeLabel(s)).join(', ')})</span>
                </div>
            </div>
            <div class="provider-actions">
                <button class="btn btn-primary btn-sm" onclick="event.stopPropagation(); contactProvider('${provider.id}')">
                    <i class="fab fa-whatsapp"></i>
                </button>
            </div>
        </div>
    `).join('');
}

/**
 * Renderiza tabela de pagamentos
 */
function renderPaymentsTable() {
    const tableBody = document.getElementById('paymentsTable');
    if (!tableBody) return;

    const payments = getMockPayments();
    
    tableBody.innerHTML = payments.map(payment => `
        <tr>
            <td>${payment.date}</td>
            <td>${payment.service}</td>
            <td>${payment.provider}</td>
            <td>${payment.amount}</td>
            <td><span class="status ${payment.status}">${payment.statusLabel}</span></td>
        </tr>
    `).join('');
}

/**
 * Renderiza jobs recentes para prestador
 */
function renderRecentJobs() {
    const container = document.getElementById('recentJobs');
    if (!container) return;

    const opportunities = getOpportunities().slice(0, 5);

    container.innerHTML = opportunities.map(job => `
        <div class="job-item" onclick="showJobDetail('${job.id}')">
            <div class="job-icon">
                <i class="fas ${getTypeIcon(job.type)}"></i>
            </div>
            <div class="job-info">
                <h4>${job.typeLabel}</h4>
                <p>${job.producer}</p>
                <div class="job-meta">
                    <span class="price">R$ ${job.estimatedValue.toLocaleString('pt-BR')}</span>
                    <span>${job.area}ha</span>
                    <span>${job.distance}km</span>
                </div>
            </div>
        </div>
    `).join('');
}

/**
 * Renderiza grid de oportunidades
 */
function renderOpportunities(opportunities) {
    const container = document.getElementById('opportunitiesGrid');
    if (!container) return;

    if (opportunities.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-search"></i>
                <h3>Nenhuma oportunidade encontrada</h3>
                <p>Tente expandir o raio de busca ou alterar os filtros</p>
            </div>
        `;
        return;
    }

    container.innerHTML = opportunities.map(opp => `
        <div class="opportunity-card">
            <div class="opportunity-header">
                <span class="opportunity-type">
                    <i class="fas ${getTypeIcon(opp.type)}"></i>
                    ${opp.typeLabel}
                </span>
                <span class="opportunity-distance">${opp.distance}km</span>
            </div>
            <div class="opportunity-details">
                <h4>${opp.cultureLabel} - ${opp.area}ha</h4>
                <p>${opp.description}</p>
            </div>
            <div class="opportunity-meta">
                <span><i class="fas fa-map-marker-alt"></i> ${opp.location}</span>
                <span><i class="fas fa-user"></i> ${opp.producer}</span>
            </div>
            <div class="opportunity-price">R$ ${opp.estimatedValue.toLocaleString('pt-BR')}</div>
            <button class="btn btn-primary btn-block" onclick="openAcceptJobModal('${opp.id}')">
                <i class="fas fa-handshake"></i> Enviar Orçamento
            </button>
        </div>
    `).join('');
}

/**
 * Renderiza tabela de serviços
 */
function renderServicesTable(services) {
    const tableBody = document.getElementById('servicesTable');
    if (!tableBody) return;

    tableBody.innerHTML = services.map(service => `
        <tr>
            <td><strong>${service.type}</strong><br><small>${service.culture}</small></td>
            <td>${service.client}</td>
            <td>${service.date}</td>
            <td><strong>R$ ${service.value.toLocaleString('pt-BR')}</strong></td>
            <td><span class="status ${service.statusClass}">${service.status}</span></td>
            <td>
                <div class="action-btns">
                    <button class="btn btn-outline btn-sm" onclick="viewServiceDetails('${service.id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-outline btn-sm" onclick="contactClient('${service.id}')">
                        <i class="fab fa-whatsapp"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

/**
 * Renderiza lista de rotas
 */
function renderRoutes() {
    const container = document.getElementById('routesList');
    if (!container) return;

    const routes = [
        { title: 'Rota Lucas do Rio Verde → Sorriso', stops: 3, distance: 180, savings: 'R$ 1.200' },
        { title: 'Rota Sorriso → Nova Mutum', stops: 2, distance: 120, savings: 'R$ 800' },
        { title: 'Rota Cuiaba → Rondonópolis', stops: 4, distance: 250, savings: 'R$ 1.800' }
    ];

    container.innerHTML = routes.map((route, index) => `
        <div class="route-card">
            <div class="route-map">
                <i class="fas fa-route"></i>
            </div>
            <div class="route-details">
                <h4>${route.title}</h4>
                <p>${route.stops} paradas programadas</p>
            </div>
            <div class="route-stats">
                <span><i class="fas fa-road"></i> ${route.distance}km</span>
                <span><i class="fas fa-piggy-bank"></i> ${route.savings}</span>
            </div>
            <button class="btn btn-outline btn-sm" onclick="viewRouteDetails(${index})">
                <i class="fas fa-map"></i>
            </button>
        </div>
    `).join('');
}

/**
 * Renderiza pagamentos do prestador
 */
function renderProviderPayments() {
    const container = document.getElementById('providerPayments');
    if (!container) return;

    const payments = [
        { date: '22/01/2024', description: 'Colheita - Fazenda Ouro Verde', amount: 25000 },
        { date: '20/01/2024', description: 'Pulverização - São Lucas', amount: 10500 },
        { date: '18/01/2024', description: 'Transporte - Vale do Juruena', amount: 8000 }
    ];

    container.innerHTML = payments.map(payment => `
        <div class="payment-item">
            <div class="payment-info">
                <div class="payment-icon">
                    <i class="fas fa-check"></i>
                </div>
                <div class="payment-details">
                    <h4>${payment.description}</h4>
                    <p>${payment.date}</p>
                </div>
            </div>
            <div class="payment-amount">
                <strong>+ R$ ${payment.amount.toLocaleString('pt-BR')}</strong>
                <span>Pago</span>
            </div>
        </div>
    `).join('');
}

/**
 * Renderiza equipamentos
 */
function renderEquipment() {
    const container = document.getElementById('equipmentGrid');
    if (!container) return;

    const equipment = [
        { name: 'John Deere S780', type: 'Colheitadeira', status: 'Disponível', year: 2022 },
        { name: 'Massey Ferguson 293', type: 'Trator', status: 'Em Serviço', year: 2020 },
        { name: 'Jacto Arbus 4000', type: 'Pulverizador', status: 'Disponível', year: 2021 }
    ];

    container.innerHTML = equipment.map(eq => `
        <div class="equipment-card">
            <div class="equipment-image">
                <i class="fas fa-tractor"></i>
            </div>
            <div class="equipment-info">
                <h4>${eq.name}</h4>
                <p>${eq.type} - ${eq.year}</p>
                <span class="equipment-status ${eq.status === 'Disponível' ? 'available' : ''}">
                    <i class="fas fa-circle"></i>
                    ${eq.status}
                </span>
            </div>
        </div>
    `).join('');
}

// =====================================================
// HANDLERS DE FORMULÁRIOS
// =====================================================

/**
 * Configura handlers de formulários
 */
function setupFormHandlers() {
    // Nova solicitação
    const newRequestForm = document.getElementById('newRequestForm');
    if (newRequestForm) {
        newRequestForm.addEventListener('submit', handleNewRequest);
    }

    // Aceitar job
    const acceptJobForm = document.getElementById('acceptJobForm');
    if (acceptJobForm) {
        acceptJobForm.addEventListener('submit', handleAcceptJob);
    }
}

/**
 * Manipula criação de nova solicitação
 */
function handleNewRequest(event) {
    event.preventDefault();

    const formData = {
        type: document.getElementById('serviceType').value,
        culture: document.getElementById('serviceCulture').value,
        area: document.getElementById('serviceArea').value,
        date: document.getElementById('serviceDate').value,
        location: document.getElementById('serviceLocation').value,
        description: document.getElementById('serviceDescription').value,
        coordinates: JSON.parse(document.getElementById('serviceLocation').dataset.coords || '[-55.9832, -12.9914]')
    };

    const newRequest = addRequest(formData);

    if (newRequest) {
        closeModal('newRequestModal');
        showNotification('Solicitação criada com sucesso!', 'success');
        
        // Limpa formulário
        document.getElementById('newRequestForm').reset();
        
        // Atualiza interface
        renderRequests();
        refreshProviderMarkers();
    } else {
        showNotification('Erro ao criar solicitação. Tente novamente.', 'error');
    }
}

/**
 * Manipula aceite de job pelo prestador
 */
function handleAcceptJob(event) {
    event.preventDefault();

    const jobId = document.getElementById('jobIdToAccept').value;
    const jobValue = document.getElementById('jobValue').value;
    const observations = document.getElementById('jobObservations').value;

    const user = getCurrentUser();
    
    // Atualiza status da solicitação
    updateRequestStatus(jobId, 'accepted', user.id, user.name || user.company);

    closeModal('acceptJobModal');
    showNotification('Orçamento enviado com sucesso!', 'success');
    
    // Limpa formulário
    document.getElementById('acceptJobForm').reset();
    
    // Atualiza interface
    renderRecentJobs();
    renderOpportunities(getOpportunities());
}

/**
 * Abre modal de nova solicitação
 */
function openNewRequestModal() {
    // Define data mínima como hoje
    const dateInput = document.getElementById('serviceDate');
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.setAttribute('min', today);
    }
    
    openModal('newRequestModal');
}

// =====================================================
// MODAIS DE DETALHE
// =====================================================

/**
 * Exibe detalhes de um serviço
 */
function showServiceDetail(requestId) {
    const request = MOCK_REQUESTS.find(r => r.id === requestId);
    if (!request) return;

    const detailEl = document.getElementById('serviceDetail');
    if (!detailEl) return;

    detailEl.innerHTML = `
        <div class="service-detail-header">
            <span class="service-badge ${request.type}">
                <i class="fas ${getTypeIcon(request.type)}"></i>
                ${request.typeLabel}
            </span>
            <h4>${request.farm}</h4>
            <p>${request.location}</p>
        </div>
        <div class="service-detail-info">
            <div class="detail-row">
                <span><i class="fas fa-ruler-combined"></i> Área</span>
                <strong>${request.area} hectares</strong>
            </div>
            <div class="detail-row">
                <span><i class="fas fa-seedling"></i> Cultura</span>
                <strong>${request.cultureLabel}</strong>
            </div>
            <div class="detail-row">
                <span><i class="fas fa-calendar"></i> Data</span>
                <strong>${formatDate(request.date)}</strong>
            </div>
            <div class="detail-row">
                <span><i class="fas fa-info-circle"></i> Status</span>
                <strong>${getStatusLabel(request.status)}</strong>
            </div>
        </div>
        ${request.description ? `
            <div class="service-detail-description">
                <h5>Observações</h5>
                <p>${request.description}</p>
            </div>
        ` : ''}
        ${request.status === 'pending' ? `
            <div class="service-detail-actions">
                <button class="btn btn-outline" onclick="closeModal('serviceDetailModal'); openEditRequestModal('${request.id}')">
                    <i class="fas fa-edit"></i> Editar
                </button>
                <button class="btn btn-danger" onclick="cancelRequest('${request.id}')">
                    <i class="fas fa-times"></i> Cancelar
                </button>
            </div>
        ` : ''}
    `;

    openModal('serviceDetailModal');
}

/**
 * Exibe detalhes de um prestador
 */
function showProviderDetail(providerId) {
    const provider = getProviderById(providerId);
    if (!provider) return;

    const detailEl = document.getElementById('providerDetail');
    if (!detailEl) return;

    detailEl.innerHTML = `
        <div class="provider-detail-header">
            <div class="provider-avatar-lg">
                <i class="fas fa-tractor"></i>
            </div>
            <div>
                <h4>${provider.name}</h4>
                <p>${provider.location}</p>
            </div>
        </div>
        <div class="provider-detail-rating">
            <i class="fas fa-star"></i>
            <strong>${provider.rating}</strong>
            <span>(${provider.totalEvaluations} avaliações)</span>
        </div>
        <div class="provider-detail-specialties">
            <h5>Especialidades</h5>
            <div class="specialty-tags">
                ${provider.specialties.map(s => `
                    <span class="specialty-tag">${getTypeLabel(s)}</span>
                `).join('')}
            </div>
        </div>
        <div class="provider-detail-actions">
            <button class="btn btn-primary btn-block" onclick="contactProvider('${provider.id}')">
                <i class="fab fa-whatsapp"></i> Contatar via WhatsApp
            </button>
        </div>
    `;

    openModal('providerDetailModal');
}

/**
 * Exibe detalhes de um job/oportunidade
 */
function showJobDetail(jobId) {
    const job = getOpportunityById(jobId);
    if (!job) return;

    const detailEl = document.getElementById('jobDetail');
    if (!detailEl) return;

    detailEl.innerHTML = `
        <div class="job-detail-header">
            <span class="job-badge ${job.type}">
                <i class="fas ${getTypeIcon(job.type)}"></i>
                ${job.typeLabel}
            </span>
            <span class="job-urgency ${job.urgency}">${getUrgencyLabel(job.urgency)}</span>
        </div>
        <h4>${job.cultureLabel} - ${job.area}ha</h4>
        <p class="job-detail-producer"><i class="fas fa-user"></i> ${job.producer}</p>
        <p class="job-detail-location"><i class="fas fa-map-marker-alt"></i> ${job.location}</p>
        
        <div class="job-detail-info">
            <div class="detail-row">
                <span>Distância</span>
                <strong>${job.distance}km</strong>
            </div>
            <div class="detail-row">
                <span>Valor Estimado</span>
                <strong>R$ ${job.estimatedValue.toLocaleString('pt-BR')}</strong>
            </div>
        </div>
        
        ${job.description ? `
            <div class="job-detail-description">
                <p>${job.description}</p>
            </div>
        ` : ''}
        
        <button class="btn btn-primary btn-block" onclick="openAcceptJobModal('${job.id}')">
            <i class="fas fa-handshake"></i> Enviar Orçamento
        </button>
    `;

    openModal('jobDetailModal');
}

/**
 * Abre modal de aceitar job
 */
function openAcceptJobModal(jobId) {
    const job = getOpportunityById(jobId);
    if (!job) return;

    document.getElementById('jobIdToAccept').value = jobId;
    document.getElementById('jobValue').value = job.estimatedValue;
    document.getElementById('jobObservations').value = '';

    // Fecha modal de detalhes se estiver aberto
    const jobDetailModal = document.getElementById('jobDetailModal');
    if (jobDetailModal) {
        jobDetailModal.classList.remove('active');
    }

    // Abre modal de aceite
    setTimeout(() => {
        openModal('acceptJobModal');
    }, 200);
}

// =====================================================
// FUNÇÕES AUXILIARES
// =====================================================

/**
 * Retorna ícone baseado no tipo de serviço
 */
function getTypeIcon(type) {
    const icons = {
        'colheita': 'fa-seedling',
        'plantio': 'fa-seedling',
        'pulverizacao': 'fa-spray-can',
        'transporte': 'fa-truck'
    };
    return icons[type] || 'fa-briefcase';
}

/**
 * Retorna label do status
 */
function getStatusLabel(status) {
    const labels = {
        'pending': 'Pendente',
        'accepted': 'Aceito',
        'in_progress': 'Em Andamento',
        'completed': 'Concluído',
        'cancelled': 'Cancelado'
    };
    return labels[status] || status;
}

/**
 * Retorna label de urgência
 */
function getUrgencyLabel(urgency) {
    const labels = {
        'low': 'Baixa Prioridade',
        'medium': 'Média Prioridade',
        'high': 'Urgente'
    };
    return labels[urgency] || urgency;
}

/**
 * Formata data para display
 */
function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}

/**
 * Contata prestador via WhatsApp
 */
function contactProvider(providerId) {
    const provider = getProviderById(providerId);
    if (!provider) return;
    
    const message = encodeURIComponent(`Olá! Encontrei seu perfil no Safraaqui e gostaria de discutir um serviço.`);
    const phone = '5565987654321'; // Número mockado
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
}

/**
 * Contata cliente via WhatsApp
 */
function contactClient(serviceId) {
    const message = encodeURIComponent(`Olá! Estou entrando em contato sobre o serviço contratado via Safraaqui.`);
    const phone = '5565987654321'; // Número mockado
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
}

/**
 * Cancela solicitação
 */
function cancelRequest(requestId) {
    if (confirm('Tem certeza que deseja cancelar esta solicitação?')) {
        updateRequestStatus(requestId, 'cancelled');
        closeModal('serviceDetailModal');
        showNotification('Solicitação cancelada com sucesso!', 'success');
        renderRequests();
    }
}

/**
 * Mostra notificação
 */
function showNotification(message, type = 'info') {
    // Cria elemento de notificação
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas ${getNotificationIcon(type)}"></i>
        <span>${message}</span>
    `;

    // Adiciona estilos inline para a notificação
    notification.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 16px 24px;
        background: ${type === 'success' ? '#10B981' : type === 'error' ? '#EF4444' : '#3B82F6'};
        color: white;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 12px;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        z-index: 9999;
        animation: slideUp 0.3s ease;
    `;

    document.body.appendChild(notification);

    // Remove após 3 segundos
    setTimeout(() => {
        notification.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

/**
 * Retorna ícone da notificação
 */
function getNotificationIcon(type) {
    const icons = {
        'success': 'fa-check-circle',
        'error': 'fa-exclamation-circle',
        'warning': 'fa-exclamation-triangle',
        'info': 'fa-info-circle'
    };
    return icons[type] || icons.info;
}

// =====================================================
// DADOS MOCKADOS ADICIONAIS
// =====================================================

/**
 * Retorna pagamentos mockados
 */
function getMockPayments() {
    return [
        { date: '20/01/2024', service: 'Colheita de Soja', provider: 'Agro Serviços MT', amount: 'R$ 25.000', status: 'paid', statusLabel: 'Pago' },
        { date: '18/01/2024', service: 'Pulverização', provider: 'Drone Agro', amount: 'R$ 10.500', status: 'paid', statusLabel: 'Pago' },
        { date: '15/01/2024', service: 'Transporte', provider: 'Terra Fretes', amount: 'R$ 8.000', status: 'paid', statusLabel: 'Pago' },
        { date: '10/01/2024', service: 'Colheita de Milho', provider: 'Agro Serviços MT', amount: 'R$ 21.000', status: 'pending', statusLabel: 'Pendente' }
    ];
}

/**
 * Retorna serviços mockados para prestador
 */
function getMockServices() {
    return [
        { id: 1, type: 'Colheita de Soja', culture: 'Soja - 500ha', client: 'Fazenda Ouro Verde', date: '25/01/2024', value: 25000, status: 'Agendado', statusClass: 'active' },
        { id: 2, type: 'Pulverização', culture: 'Milho - 350ha', client: 'Fazenda São Lucas', date: '26/01/2024', value: 10500, status: 'Pendente', statusClass: 'pending' },
        { id: 3, type: 'Colheita de Milho', culture: 'Milho - 420ha', client: 'Fazenda São Lucas', date: '20/01/2024', value: 21000, status: 'Concluído', statusClass: 'completed' },
        { id: 4, type: 'Transporte', culture: 'Soja - 200t', client: 'Fazenda Ouro Verde', date: '15/01/2024', value: 8000, status: 'Concluído', statusClass: 'completed' }
    ];
}

// =====================================================
// EVENT LISTENERS GERAIS
// =====================================================

/**
 * Configura event listeners adicionais
 */
function setupEventListeners() {
    // Scroll do header
    window.addEventListener('scroll', () => {
        const header = document.querySelector('.header');
        if (header) {
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
    });

    // Fecha dropdowns ao clicar fora
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.dropdown')) {
            document.querySelectorAll('.dropdown-menu').forEach(menu => {
                menu.classList.remove('active');
            });
        }
    });
}

// =====================================================
// INICIALIZAÇÃO
// =====================================================

// Inicializa quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

// Exporta funções para uso global
window.openModal = openModal;
window.closeModal = closeModal;
window.switchModal = switchModal;
window.toggleMobileMenu = toggleMobileMenu;
window.toggleSidebar = toggleSidebar;
window.selectRole = selectRole;
window.selectRegisterRole = selectRegisterRole;
window.handleLogin = handleLogin;
window.handleRegister = handleRegister;
window.handleLogout = handleLogout;
window.handleNewRequest = handleNewRequest;
window.handleAcceptJob = handleAcceptJob;
window.openNewRequestModal = openNewRequestModal;
window.openAcceptJobModal = openAcceptJobModal;
window.showServiceDetail = showServiceDetail;
window.showProviderDetail = showProviderDetail;
window.showJobDetail = showJobDetail;
window.contactProvider = contactProvider;
window.contactClient = contactClient;
window.cancelRequest = cancelRequest;
window.showNotification = showNotification;

// Funções de localização ( wrappers que serão sobrescritas por map.js quando carregado )
window.useCurrentLocation = function() {
    if (typeof window.addCurrentLocationMarker === 'function') {
        window.addCurrentLocationMarker();
    } else {
        showNotification('Funcionalidade em carregamento...', 'info');
    }
};

window.setupMapClick = function() {
    // Esta função será configurada pelo map.js
};
