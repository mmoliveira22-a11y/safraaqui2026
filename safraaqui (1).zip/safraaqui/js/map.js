/**
 * SAFRAAQUI - Integração com Mapbox
 * Módulo de Mapas e Geolocalização v1.0
 */

// =====================================================
// CONFIGURAÇÃO DO MAPBOX
// =====================================================

// Token do Mapbox - Substituir com seu token real
const MAPBOX_TOKEN = 'pk.eyJ1IjoiZXhhbXBsZSIsImEiOiJjbGZ5MjA2M2cwMDB4M3FwaDNtNHB2N3Y5In0.ExampleToken';

let map = null;
let markers = [];
let userLocation = null;

// =====================================================
// INICIALIZAÇÃO DO MAPA
// =====================================================

/**
 * Inicializa o mapa na página atual
 */
function initMap() {
    const dashboardMapEl = document.getElementById('dashboardMap');
    const providerMapEl = document.getElementById('providerMap');

    if (dashboardMapEl || providerMapEl) {
        // Determina qual mapa inicializar
        const mapContainer = dashboardMapEl || providerMapEl;
        
        // Centraliza no Mato Grosso (região central do agronegócio brasileiro)
        const centerCoords = [-55.9832, -12.9914]; // Lucas do Rio Verde - MT

        try {
            mapboxgl.accessToken = MAPBOX_TOKEN;

            map = new mapboxgl.Map({
                container: mapContainer.id,
                style: 'mapbox://styles/mapbox/light-v11',
                center: centerCoords,
                zoom: 7,
                attributionControl: true
            });

            // Adiciona controles de navegação
            map.addControl(new mapboxgl.NavigationControl(), 'top-right');

            // Adiciona controles de geolocalização
            map.addControl(new mapboxgl.GeolocateControl({
                positionOptions: {
                    enableHighAccuracy: true
                },
                trackUserLocation: true,
                showUserHeading: true
            }), 'top-right');

            // Aguarda carregamento do mapa
            map.on('load', () => {
                console.log('Mapa Safraaqui carregado com sucesso');
                
                // Adiciona marcadores baseados na página
                if (dashboardMapEl) {
                    loadProducerMapMarkers();
                } else if (providerMapEl) {
                    loadProviderMapMarkers();
                }
            });

            // Trata erros de carregamento
            map.on('error', (e) => {
                console.error('Erro no mapa:', e);
                showMapError(mapContainer);
            });

        } catch (error) {
            console.error('Erro ao inicializar mapa:', error);
            showMapError(mapContainer);
        }
    }
}

/**
 * Exibe erro quando o mapa não carrega
 */
function showMapError(container) {
    container.innerHTML = `
        <div class="map-error">
            <i class="fas fa-map-marked-alt"></i>
            <h3>Mapa Temporariamente Indisponível</h3>
            <p>Configure seu token do Mapbox para visualizar o mapa.</p>
            <small>Token atual: ${MAPBOX_TOKEN.substring(0, 20)}...</small>
        </div>
    `;
}

// =====================================================
// MARCADORES DO MAPA DO PRODUTOR
// =====================================================

/**
 * Carrega marcadores de prestadores no mapa do produtor
 */
function loadProducerMapMarkers() {
    clearMarkers();

    // Adiciona marcadores de prestadores
    const providers = getProviders();
    
    providers.forEach(provider => {
        const marker = createProviderMarker(provider);
        markers.push(marker);
    });

    // Ajusta zoom para mostrar todos os marcadores
    fitMapToMarkers();
}

/**
 * Cria marcador de prestador
 */
function createProviderMarker(provider) {
    // Cria elemento DOM personalizado
    const el = document.createElement('div');
    el.className = 'custom-marker provider';
    el.innerHTML = '<i class="fas fa-tractor"></i>';
    el.title = provider.name;

    // Cria popup
    const popup = new mapboxgl.Popup({ offset: 25 })
        .setHTML(`
            <div class="popup-marker provider">
                <i class="fas fa-tractor"></i>
                <div>
                    <h4>${provider.name}</h4>
                    <p>${provider.location}</p>
                    <p style="margin-top: 4px;">
                        <i class="fas fa-star" style="color: #F9A825;"></i>
                        ${provider.rating} - ${getTypeLabel(provider.specialties[0])}
                    </p>
                </div>
            </div>
        `);

    // Cria marcador
    const marker = new mapboxgl.Marker(el)
        .setLngLat(provider.coordinates)
        .setPopup(popup)
        .addTo(map);

    // Adiciona clique no marcador
    el.addEventListener('click', () => {
        showProviderDetail(provider.id);
    });

    return marker;
}

/**
 * Adiciona marcador de nova solicitação ao mapa
 */
function addRequestMarker(request) {
    const el = document.createElement('div');
    el.className = 'custom-marker request';
    
    // Define ícone baseado no tipo de serviço
    const icons = {
        'colheita': 'fa-seedling',
        'plantio': 'fa-seedling',
        'pulverizacao': 'fa-spray-can',
        'transporte': 'fa-truck'
    };
    
    el.innerHTML = `<i class="fas ${icons[request.type] || 'fa-briefcase'}"></i>`;
    el.title = request.typeLabel;

    const popup = new mapboxgl.Popup({ offset: 25 })
        .setHTML(`
            <div class="popup-marker request">
                <i class="fas ${icons[request.type] || 'fa-briefcase'}"></i>
                <div>
                    <h4>${request.typeLabel}</h4>
                    <p>${request.location}</p>
                    <p style="margin-top: 4px;">
                        <strong>${request.area} ha</strong> - ${request.cultureLabel}
                    </p>
                </div>
            </div>
        `);

    const marker = new mapboxgl.Marker(el)
        .setLngLat(request.coordinates)
        .setPopup(popup)
        .addTo(map);

    markers.push(marker);
    return marker;
}

// =====================================================
// MARCADORES DO MAPA DO PRESTADOR
// =====================================================

/**
 * Carrega marcadores de oportunidades no mapa do prestador
 */
function loadProviderMapMarkers() {
    clearMarkers();

    // Adiciona marcadores de oportunidades
    const opportunities = getOpportunities();
    
    opportunities.forEach(opp => {
        const marker = createOpportunityMarker(opp);
        markers.push(marker);
    });

    // Ajusta zoom
    fitMapToMarkers();
}

/**
 * Cria marcador de oportunidade
 */
function createOpportunityMarker(opportunity) {
    const el = document.createElement('div');
    el.className = 'custom-marker request';
    
    const icons = {
        'colheita': 'fa-seedling',
        'plantio': 'fa-seedling',
        'pulverizacao': 'fa-spray-can',
        'transporte': 'fa-truck'
    };
    
    el.innerHTML = `<i class="fas ${icons[opportunity.type] || 'fa-briefcase'}"></i>`;
    el.title = opportunity.typeLabel;

    const popup = new mapboxgl.Popup({ offset: 25 })
        .setHTML(`
            <div class="popup-marker request">
                <i class="fas ${icons[opportunity.type] || 'fa-briefcase'}"></i>
                <div>
                    <h4>${opportunity.typeLabel}</h4>
                    <p>${opportunity.location}</p>
                    <p style="margin-top: 4px;">
                        <strong>${opportunity.area} ha</strong> - ${opportunity.distance}km de distância
                    </p>
                </div>
            </div>
        `);

    const marker = new mapboxgl.Marker(el)
        .setLngLat(opportunity.coordinates)
        .setPopup(popup)
        .addTo(map);

    el.addEventListener('click', () => {
        showJobDetail(opportunity.id);
    });

    return marker;
}

// =====================================================
// FUNÇÕES AUXILIARES
// =====================================================

/**
 * Limpa todos os marcadores do mapa
 */
function clearMarkers() {
    markers.forEach(marker => {
        marker.remove();
    });
    markers = [];
}

/**
 * Ajusta o zoom do mapa para mostrar todos os marcadores
 */
function fitMapToMarkers() {
    if (markers.length === 0 || !map) return;

    const bounds = new mapboxgl.LngLatBounds();
    
    markers.forEach(marker => {
        const lngLat = marker.getLngLat();
        bounds.extend(lngLat);
    });

    map.fitBounds(bounds, {
        padding: 50,
        maxZoom: 12,
        duration: 1000
    });
}

/**
 * Centraliza o mapa em coordenadas específicas
 */
function flyTo(coordinates, zoom = 10) {
    if (!map) return;

    map.flyTo({
        center: coordinates,
        zoom: zoom,
        essential: true,
        duration: 1500
    });
}

/**
 * Obtém coordenadas de um endereço (simulado)
 */
async function geocodeAddress(address) {
    // Em produção, isso chamaria a API de geocodificação do Mapbox
    // Por enquanto, retorna coordenadas fixas para demonstração
    const mockCoords = {
        'lucas do rio verde': [-55.9832, -12.9914],
        'sorriso': [-55.7000, -12.5500],
        'cuiabá': [-56.0963, -15.5961],
        'rondonópolis': [-54.6200, -16.4700],
        'sinop': [-55.5000, -11.8500],
        'nova mutum': [-56.0800, -13.8400],
        'campo verde': [-55.1700, -15.0400]
    };

    const key = address.toLowerCase();
    for (const [city, coords] of Object.entries(mockCoords)) {
        if (key.includes(city)) {
            return coords;
        }
    }

    // Retorna coordenadas genéricas se não encontrar
    return [-55.9832, -12.9914];
}

/**
 * Obtém endereço de coordenadas (simulado)
 */
async function reverseGeocode(coordinates) {
    // Em produção, isso chamaria a API de geocodificação reversa do Mapbox
    return 'Localização Selecionada';
}

/**
 * Calcula rota entre dois pontos
 */
async function calculateRoute(startCoords, endCoords) {
    // Em produção, isso chamaria a API de direções do Mapbox
    // Por enquanto, retorna distância estimada
    const distance = Math.sqrt(
        Math.pow(endCoords[0] - startCoords[0], 2) +
        Math.pow(endCoords[1] - startCoords[1], 2)
    ) * 111; // Aproximação: 1 grau ≈ 111km

    return {
        distance: Math.round(distance),
        duration: Math.round(distance / 60) // A 60km/h
    };
}

/**
 * Filtra marcadores por tipo de serviço
 */
function filterMarkersByType(type) {
    markers.forEach(marker => {
        const el = marker.getElement();
        if (type === 'all') {
            el.style.display = 'flex';
        } else {
            const isMatch = el.classList.contains(type) || 
                           el.querySelector(`i`)?.classList.contains(getIconClass(type));
            el.style.display = isMatch ? 'flex' : 'none';
        }
    });
}

/**
 * Obtém classe de ícone baseada no tipo
 */
function getIconClass(type) {
    const icons = {
        'colheita': 'fa-seedling',
        'plantio': 'fa-seedling',
        'pulverizacao': 'fa-spray-can',
        'transporte': 'fa-truck'
    };
    return icons[type] || 'fa-briefcase';
}

/**
 * Atualiza marcadores do mapa do prestador com filtros aplicados
 */
function updateProviderMarkers(filteredOpportunities) {
    clearMarkers();
    
    filteredOpportunities.forEach(opp => {
        const marker = createOpportunityMarker(opp);
        markers.push(marker);
    });

    fitMapToMarkers();
}

/**
 * Atualiza marcadores do mapa do produtor
 */
function refreshProducerMarkers() {
    loadProducerMapMarkers();
}

/**
 * Atualiza marcadores do mapa do prestador
 */
function refreshProviderMarkers() {
    loadProviderMapMarkers();
}

// =====================================================
// FUNÇÕES DE GEOLOCALIZAÇÃO
// =====================================================

/**
 * Obtém localização atual do usuário
 */
function getCurrentLocation() {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
            reject(new Error('Geolocalização não suportada pelo navegador'));
            return;
        }

        navigator.geolocation.getCurrentPosition(
            (position) => {
                const coords = [
                    position.coords.longitude,
                    position.coords.latitude
                ];
                userLocation = coords;
                resolve(coords);
            },
            (error) => {
                reject(error);
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
        );
    });
}

/**
 * Adiciona marcador da localização atual
 */
async function addCurrentLocationMarker() {
    try {
        const coords = await getCurrentLocation();
        
        // Remove marcador anterior se existir
        const existingMarker = markers.find(m => m._element?.classList.contains('current-location'));
        if (existingMarker) {
            existingMarker.remove();
        }

        // Cria novo marcador
        const el = document.createElement('div');
        el.className = 'custom-marker current-location';
        el.style.background = '#3B82F6';
        el.style.borderColor = '#FFFFFF';
        el.innerHTML = '<i class="fas fa-crosshairs"></i>';
        el.title = 'Sua Localização';

        const marker = new mapboxgl.Marker(el)
            .setLngLat(coords)
            .addTo(map);

        markers.push(marker);
        flyTo(coords, 12);

        return coords;
    } catch (error) {
        console.error('Erro ao obter localização:', error);
        showNotification('Não foi possível obter sua localização. Verifique as permissões.', 'error');
        return null;
    }
}

/**
 * Adiciona marcador ao clicar no mapa
 */
function setupMapClick() {
    if (!map) return;

    map.on('click', async (e) => {
        const coords = [e.lngLat.lng, e.lngLat.lat];
        
        // Se estiver no modal de nova solicitação
        const locationInput = document.getElementById('serviceLocation');
        if (locationInput) {
            const address = await reverseGeocode(coords);
            locationInput.value = address;
            
            // Armazena coordenadas
            locationInput.dataset.coords = JSON.stringify(coords);

            // Adiciona marcador temporário
            addTempMarker(coords);
        }
    });
}

/**
 * Adiciona marcador temporário no mapa
 */
function addTempMarker(coords) {
    // Remove marcador temporário anterior
    const tempMarker = markers.find(m => m._element?.classList.contains('temp-marker'));
    if (tempMarker) {
        tempMarker.remove();
        markers = markers.filter(m => m !== tempMarker);
    }

    // Adiciona novo marcador
    const el = document.createElement('div');
    el.className = 'custom-marker temp-marker';
    el.style.background = '#2E7D32';
    el.innerHTML = '<i class="fas fa-map-marker-alt"></i>';

    const marker = new mapboxgl.Marker(el)
        .setLngLat(coords)
        .addTo(map);

    markers.push(marker);
}

// =====================================================
// INICIALIZAÇÃO
// =====================================================

// Inicializa quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    // Pequeno atraso para garantir que o Mapbox GL JS esteja carregado
    setTimeout(() => {
        initMap();
    }, 100);
});

// Exporta funções para uso global
window.initMap = initMap;
window.loadProducerMapMarkers = loadProducerMapMarkers;
window.loadProviderMapMarkers = loadProviderMapMarkers;
window.addCurrentLocationMarker = addCurrentLocationMarker;
window.clearMarkers = clearMarkers;
window.flyTo = flyTo;
window.filterMarkersByType = filterMarkersByType;
window.geocodeAddress = geocodeAddress;
window.reverseGeocode = reverseGeocode;
window.calculateRoute = calculateRoute;
window.getCurrentLocation = getCurrentLocation;
window.addRequestMarker = addRequestMarker;
window.refreshProducerMarkers = refreshProducerMarkers;
window.refreshProviderMarkers = refreshProviderMarkers;
window.setupMapClick = setupMapClick;
